import UIKit

extension UIColor {
    static let customColor = UIColor(red: 0.25, green: 0.5, blue: 0.75, alpha: 1)
}

